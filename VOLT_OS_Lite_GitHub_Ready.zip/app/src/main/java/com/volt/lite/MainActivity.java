package com.volt.lite;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.*;
import android.hardware.*;
import android.location.*;
import android.net.wifi.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.*;
import java.text.SimpleDateFormat;

public class MainActivity extends Activity implements SensorEventListener {
    LinearLayout root; TextView gpsText, compassText; LocationManager lm; SensorManager sm;
    LocationListener listener; Sensor rotation;
    TextView aiResponse; EditText aiInput; boolean navigatorVisible=false;
    int navy = 0xff101b30;
    @Override public void onCreate(Bundle state) { super.onCreate(state); home(); }
    TextView title(String text, int size) { TextView t=new TextView(this); t.setText(text); t.setTextSize(size); t.setTextColor(-1); t.setPadding(18,16,18,16); return t; }
    void init(String heading) {
        root=new LinearLayout(this); root.setOrientation(1); root.setBackgroundColor(navy);
        ScrollView scroll=new ScrollView(this); scroll.addView(root); setContentView(scroll);
        root.addView(title(heading,26));
    }
    void action(String name, Runnable click) { Button b=new Button(this); b.setText(name); root.addView(b); b.setOnClickListener(v->click.run()); }
    void home() {
        stopSensors(); navigatorVisible=false; init("⚡ VOLT OS Lite"); root.addView(title("Offline-first • Android 8.1+",15));
        action("VOLT AI (offline)",this::voltAi);
        action("VOLT Navigator",this::navigator);
        action("Offline Map Viewer",this::mapViewer);
        action("FM Radio",this::radio);
        action("VOLT Connect",this::connect);
        action("Installed Apps",this::apps);
    }
    void navigator() {
        navigatorVisible=true; init("VOLT Navigator"); gpsText=title("GPS: waiting for satellite fix...",16); root.addView(gpsText);
        compassText=title("Compass: checking sensors...",16); root.addView(compassText);
        action("Open offline map",this::mapViewer); action("Back",this::home);
        sm=(SensorManager)getSystemService(SENSOR_SERVICE);
        rotation=sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        if(rotation!=null) sm.registerListener(this,rotation,SensorManager.SENSOR_DELAY_UI);
        else compassText.setText("Compass sensor unavailable");
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},101);
        } else startGps();
    }
    void startGps() {
        lm=(LocationManager)getSystemService(LOCATION_SERVICE);
        if(!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) { gpsText.setText("Enable Location/GPS in phone settings"); return; }
        listener=new LocationListener() {
            @Override public void onLocationChanged(Location l) {
                gpsText.setText(String.format(Locale.US,"Latitude: %.6f\nLongitude: %.6f\nAccuracy: ±%.0f m\nAltitude: %s\nProvider: %s",l.getLatitude(),l.getLongitude(),l.getAccuracy(),l.hasAltitude()?String.format(Locale.US,"%.1f m",l.getAltitude()):"Unavailable",l.getProvider()));
            }
            @Override public void onStatusChanged(String p,int s,Bundle e) {}
            @Override public void onProviderEnabled(String p) {}
            @Override public void onProviderDisabled(String p) { gpsText.setText("GPS disabled"); }
        };
        try { lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,2000,1,listener); }
        catch(SecurityException e) { gpsText.setText("Location permission required"); }
    }
    @Override public void onRequestPermissionsResult(int code,String[] permissions,int[] results) {
        super.onRequestPermissionsResult(code,permissions,results);
        if(code==101 && results.length>0 && results[0]==PackageManager.PERMISSION_GRANTED && navigatorVisible) startGps();
        if(code==102 && results.length>0 && results[0]==PackageManager.PERMISSION_GRANTED) scanWifi();
    }
    @Override public void onSensorChanged(SensorEvent e) {
        if(compassText==null || e.sensor.getType()!=Sensor.TYPE_ROTATION_VECTOR) return;
        float[] r=new float[9], o=new float[3]; SensorManager.getRotationMatrixFromVector(r,e.values);
        SensorManager.getOrientation(r,o); float deg=(float)((Math.toDegrees(o[0])+360)%360);
        compassText.setText(String.format(Locale.US,"Compass: %.0f° (magnetic, approximate)",deg));
    }
    @Override public void onAccuracyChanged(Sensor s,int accuracy) {}
    void mapViewer() {
        stopSensors(); navigatorVisible=false; init("Offline Map Viewer");
        root.addView(title("Map tiles must be bundled in assets/maps/{z}/{x}/{y}.png before compiling. This starter includes a local map-file inventory, not a rendered map or routing engine.",15));
        try { String[] files=getAssets().list("maps"); root.addView(title("Map asset entries: "+(files==null?0:files.length),16)); }
        catch(Exception ex) { root.addView(title("No map assets found",16)); }
        action("Back",this::home);
    }
    void radio() {
        stopSensors(); navigatorVisible=false; init("FM Radio"); root.addView(title("Requires the phone's built-in FM app, working FM hardware and possibly wired headphones as antenna. No internet streaming.",15));
        action("Open existing FM app",()->{
            PackageManager pm=getPackageManager(); boolean opened=false;
            for(String pkg:new String[]{"com.android.fmradio","com.mediatek.fmradio","com.vivo.fmradio","com.android.fm"}) {
                Intent i=pm.getLaunchIntentForPackage(pkg);
                if(i!=null) { try { startActivity(i); opened=true; break; } catch(Exception ignored) {} }
            }
            if(!opened) Toast.makeText(this,"FM app not found. Check installed apps manually.",Toast.LENGTH_LONG).show();
        }); action("Back",this::home);
    }
    void connect() {
        stopSensors(); navigatorVisible=false; init("VOLT Connect");
        root.addView(title("Find nearby Wi-Fi networks and open Android Wi-Fi settings to connect with permission. SIM-free voice calls require working internet and a compatible VoIP app/service.",15));
        action("Scan nearby Wi-Fi",this::scanWifi);
        action("Open Wi-Fi settings",()->startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)));
        action("Find installed calling apps",this::apps);
        action("Back",this::home);
    }
    void scanWifi() {
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},102); return;
        }
        WifiManager wm=(WifiManager)getApplicationContext().getSystemService(WIFI_SERVICE);
        if(wm==null || !wm.isWifiEnabled()) { root.addView(title("Enable Wi-Fi and Location in Android settings, then scan again.",14)); return; }
        try {
            // Android throttles scans; getScanResults may return cached entries.
            wm.startScan();
            List<ScanResult> results=wm.getScanResults();
            root.addView(title("Networks (may be cached): "+results.size(),16));
            HashSet<String> shown=new HashSet<>();
            for(ScanResult r:results) {
                if(r.SSID==null || r.SSID.length()==0 || !shown.add(r.SSID)) continue;
                boolean secured=r.capabilities.contains("WEP") || r.capabilities.contains("PSK") || r.capabilities.contains("EAP") || r.capabilities.contains("SAE");
                root.addView(title(r.SSID+" • "+(secured?"Protected":"Potentially open")+" • "+r.level+" dBm",14));
            }
            root.addView(title("Only connect to networks you are allowed to use. Open networks may require a captive portal sign-in.",13));
        } catch(SecurityException e) { root.addView(title("Wi-Fi scanning requires Location permission and Location services enabled.",14)); }
    }
    void voltAi() {
        stopSensors(); navigatorVisible=false; init("VOLT AI • Offline");
        root.addView(title("On-device command assistant. No cloud, account, internet, or AI model. Type a command below.",14));
        aiInput=new EditText(this); aiInput.setSingleLine(true);
        aiInput.setTextColor(0xffffffff); aiInput.setHintTextColor(0xffb0bdce);
        aiInput.setHint("Try: open navigator"); root.addView(aiInput);
        aiResponse=title("Commands: help, time, date, open navigator, open map, open connect, scan wifi, open radio, open apps, open settings, compass, gps, privacy",15);
        root.addView(aiResponse);
        action("Run offline command",()->runAiCommand(aiInput.getText().toString()));
        action("Help",()->runAiCommand("help"));
        action("Back",this::home);
    }
    void runAiCommand(String input) {
        String c=input.toLowerCase(Locale.ROOT).trim().replaceAll("\\s+"," ");
        if(c.isEmpty()) { aiResponse.setText("Type a command first."); return; }
        if(c.equals("help") || c.equals("commands")) {
            aiResponse.setText("Offline commands: time, date, navigator, gps, compass, map, connect, wifi, scan wifi, radio, apps, settings, privacy. No open-ended AI chat is available offline.");
        } else if(c.equals("time") || c.equals("what time is it")) {
            aiResponse.setText(new SimpleDateFormat("h:mm a",Locale.getDefault()).format(new Date()));
        } else if(c.equals("date") || c.equals("what is the date")) {
            aiResponse.setText(new SimpleDateFormat("EEEE, d MMMM yyyy",Locale.getDefault()).format(new Date()));
        } else if(c.contains("navigator") || c.equals("gps") || c.contains("location") || c.equals("compass")) {
            navigator();
        } else if(c.equals("map") || c.contains("open map")) {
            mapViewer();
        } else if(c.contains("connect") || c.equals("wifi") || c.contains("wi-fi") || c.contains("scan wifi")) {
            connect();
            if(c.contains("scan")) scanWifi();
        } else if(c.contains("radio") || c.equals("fm")) {
            radio();
        } else if(c.contains("apps") || c.contains("applications")) {
            apps();
        } else if(c.contains("settings")) {
            try { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
            catch(Exception e) { aiResponse.setText("Settings app unavailable."); }
        } else if(c.equals("privacy")) {
            aiResponse.setText("VOLT AI executes fixed commands locally. It does not record audio, send data to a server, or require internet. GPS and Wi-Fi need Android location permission.");
        } else {
            aiResponse.setText("I don't recognize that offline command. Type 'help' to see supported commands.");
        }
    }
    void apps() {
        stopSensors(); navigatorVisible=false; init("Installed Apps");
        PackageManager pm=getPackageManager(); Intent intent=new Intent(Intent.ACTION_MAIN); intent.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> items=pm.queryIntentActivities(intent,0);
        Collections.sort(items,new ResolveInfo.DisplayNameComparator(pm));
        for(ResolveInfo ri:items) action(ri.loadLabel(pm).toString(),()->{
            try { Intent launch=new Intent(Intent.ACTION_MAIN); launch.addCategory(Intent.CATEGORY_LAUNCHER);
                launch.setClassName(ri.activityInfo.packageName,ri.activityInfo.name); startActivity(launch);
            } catch(Exception ex) { Toast.makeText(this,"Cannot open app",Toast.LENGTH_SHORT).show(); }
        }); action("Back",this::home);
    }
    void stopSensors() { if(lm!=null && listener!=null) { lm.removeUpdates(listener); listener=null; } if(sm!=null) sm.unregisterListener(this); }
    @Override protected void onPause() { super.onPause(); stopSensors(); }
    @Override protected void onResume() {
        super.onResume();
        if(navigatorVisible && gpsText!=null) {
            sm=(SensorManager)getSystemService(SENSOR_SERVICE);
            rotation=sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
            if(rotation!=null) sm.registerListener(this,rotation,SensorManager.SENSOR_DELAY_UI);
            if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED && listener==null) startGps();
        }
    }
    @Override public void onBackPressed() { home(); }
}
