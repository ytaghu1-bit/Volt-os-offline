# VOLT OS Lite v1.2 — Offline command assistant

Android Java source project for Android 8.0+ (minSdk 26), intended for testing on Vivo 1820 / Funtouch OS. This is a launcher application, NOT a flashable operating system.

## VOLT AI

Open **VOLT AI (offline)** from the home screen. Type `help` for supported commands. Commands include time, date, navigator, gps, compass, map, connect, wifi, scan wifi, radio, apps, settings, and privacy. Commands run locally with no cloud API, speech recognition, internet connection, model downloads, or heavy AI dependencies. This is a deterministic command assistant, not a generative AI model.

## Existing modules

- Navigator: GPS coordinates and magnetic compass when hardware and permission allow.
- Connect: Wi-Fi discovery and Android Wi-Fi settings; only use authorized networks. No built-in VoIP calling engine.
- FM: attempts to launch a compatible existing FM radio app; hardware support unverified.
- Offline map: asset inventory placeholder, not a rendered map or routing service.
- Launcher: installed app list and Android HOME intent.

## Build

Open as a Gradle Android project in an environment supporting Android Gradle Plugin 8.2.2, JDK 17 and Android SDK 34. Run `gradle assembleDebug` or `./gradlew assembleDebug` if you add a Gradle wrapper. The archive does not include a Gradle wrapper, APK, or map data. A phone-only cloud build is possible after uploading the source to a build service; AIDE compatibility is not guaranteed.

## Safety and privacy

The app requests fine location for GPS/Wi-Fi scans, and Wi-Fi state permissions. No INTERNET permission is requested. GPS accuracy is not exact; Wi-Fi scans may be cached or throttled. This project has not been compiled or tested on a Vivo 1820. Back up your data and do not flash it as firmware.
